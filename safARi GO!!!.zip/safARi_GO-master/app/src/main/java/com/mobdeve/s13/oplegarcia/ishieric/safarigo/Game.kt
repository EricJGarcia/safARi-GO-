package com.mobdeve.s13.oplegarcia.ishieric.safarigo

class Game(gameId: String, description: String) {
    var gameId = gameId
        private set

    var description = description
        private set
}